(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_js_transform_ts_c36dd5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_js_transform_ts_c36dd5._.js",
  "chunks": [
    "chunks/node_modules_53c1e4._.js",
    "chunks/_0b8f1c._.js"
  ],
  "source": "dynamic"
});
