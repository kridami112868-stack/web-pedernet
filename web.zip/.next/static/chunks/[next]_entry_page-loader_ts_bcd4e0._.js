(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[next]_entry_page-loader_ts_bcd4e0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[next]_entry_page-loader_ts_bcd4e0._.js",
  "chunks": [
    "static/chunks/[root of the server]__eea580._.js",
    "static/chunks/node_modules_react_b2385d._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
    "static/chunks/node_modules_react-dom_f14d04._.js",
    "static/chunks/node_modules_a6e291._.js",
    "static/chunks/[turbopack]_dev_client_38d6c6._.js",
    "static/chunks/node_modules_next_dist_pages_6fcf02._.js"
  ],
  "source": "entry"
});
