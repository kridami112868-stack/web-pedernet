(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[next]_entry_page-loader_ts_68249b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[next]_entry_page-loader_ts_68249b._.js",
  "chunks": [
    "static/chunks/node_modules_next_a316ef._.js",
    "static/chunks/node_modules_react_1cad9b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
    "static/chunks/node_modules_react-dom_f14d04._.js",
    "static/chunks/node_modules_tailwind-merge_dist_lib_7ed4a1._.js",
    "static/chunks/node_modules_@react-aria_31c1ae._.js",
    "static/chunks/node_modules_@react-aria_0bd367._.js",
    "static/chunks/node_modules_framer-motion_dist_es_f5eb40._.js",
    "static/chunks/node_modules_@nextui-org_react-rsc-utils_dist_0060d3._.js",
    "static/chunks/node_modules_983c1e._.js",
    "static/chunks/[root of the server]__de69fe._.js",
    "static/chunks/node_modules_next_dist_pages_76bdbd._.js"
  ],
  "source": "entry"
});
