__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_3e68ae._.js",
  "static/chunks/node_modules_react_1cad9b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
  "static/chunks/node_modules_react-dom_f14d04._.js",
  "static/chunks/node_modules_3bc624._.js",
  "static/chunks/[root of the server]__ebd352._.js",
  "static/chunks/[root of the server]__992e02._.css",
  "static/chunks/node_modules_next_dist_pages_2b6d10._.js",
  "static/chunks/[next]_entry_page-loader_ts_6eed0c._.js",
  "static/chunks/[next]_entry_page-loader_ts_7d1ea6._.js"
])
