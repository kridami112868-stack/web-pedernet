__turbopack_load_page_chunks__("/pricing", [
  "static/chunks/node_modules_next_a316ef._.js",
  "static/chunks/node_modules_react_1cad9b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
  "static/chunks/node_modules_react-dom_f14d04._.js",
  "static/chunks/node_modules_tailwind-merge_dist_lib_7ed4a1._.js",
  "static/chunks/node_modules_@react-aria_31c1ae._.js",
  "static/chunks/node_modules_@react-aria_0bd367._.js",
  "static/chunks/node_modules_framer-motion_dist_es_f5eb40._.js",
  "static/chunks/node_modules_@nextui-org_react-rsc-utils_dist_0060d3._.js",
  "static/chunks/node_modules_983c1e._.js",
  "static/chunks/[root of the server]__3b95cd._.js",
  "static/chunks/node_modules_next_dist_pages_069e8f._.js",
  "static/chunks/[next]_entry_page-loader_ts_a110ab._.js",
  "static/chunks/[next]_entry_page-loader_ts_8e3b8f._.js"
])
