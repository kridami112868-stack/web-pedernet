import React from "react";
export const ListboxWrapper = ({children}) => (
  <div className="w-full max-w-[260px] py-2">
    {children}
  </div>
);
